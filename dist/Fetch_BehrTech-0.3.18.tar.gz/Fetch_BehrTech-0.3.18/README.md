
![publish-pypi](https://github.com/matthewashley1/Fetch_BehrTech/workflows/publish-pypi/badge.svg)

# Fetch_BehrTech

A package to interface with BehrTech's gateway computer API for requesting and parsing data. Also has built in functionality
for pushing data to the IBM IoT Platform and Bokeh Plotting.

## License

Fetch_BehrTech is released under the [MIT](https://opensource.org/licenses/MIT) license
