
from fetch_behrtech.Parsers.Parser import Parser
from fetch_behrtech.Parsers.JSON_Parser import JSONParser
